def hola_mundo():
    return "Hola Mundo"

if __name__ == "__main__":
    print(hola_mundo())