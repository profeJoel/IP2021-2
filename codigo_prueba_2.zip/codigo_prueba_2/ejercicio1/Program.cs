﻿using System;

namespace ejercicio1
{
    class Program
    {
        static String HolaMundo()
        {
            return "Hola Mundo";
        }

        static void Main(string[] args)
        {
            Console.WriteLine(HolaMundo());
        }
    }
}
